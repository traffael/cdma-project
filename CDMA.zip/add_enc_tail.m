function P_tail = add_enc_tail(P)
    P_tail = [P zeros(8,1)'];
end