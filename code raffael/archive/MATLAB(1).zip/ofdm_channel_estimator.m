function channel_estimate = ofdm_channel_estimator(ch_est_seq_rx_td, ch_est_seq_tx, num_subcarriers, guard_interval, SNR, algorithm)
% ch_est_seq_rx_td: The received channel estimation sequence in time-domain 
% ch_est_seq_tx: The transmitted channel estimation sequence in frequency-domain
% SNR: used for MMSE algorithm
% algorithm: Chooses the estimation algorithm. Valid values are 'LS', 'MMSE' and 'MST'

% The following line is only interesting if the channel estimation sequence consists of several OFDM symbols.
ch_est_seq_rx_td = reshape(ch_est_seq_rx_td, num_subcarriers + guard_interval, length(ch_est_seq_rx_td) / (num_subcarriers + guard_interval));

% CP removal
ch_est_seq_rx_td(1:guard_interval, :) = []; % Remove the CP

% normalization
ch_est_seq_rx = fft(ch_est_seq_rx_td) / sqrt(num_subcarriers);

% LS estimation:
channel_estimate_ls = %...

% mean for multiple channel estimation OFDM symbols
channel_estimate_ls = mean(channel_estimate_ls, 2);

% At this point, we have the trivial LS estimates
switch algorithm
  case 'LS'
    channel_estimate = channel_estimate_ls;
  case 'MST'
    % MST-Method for smoothing in time domain (Most Significant Taps; Set taps that belong to noise only to zero)
    %...
    %...
    %channel_estimate = %...
  case 'MMSE'
    % Parameters for MMSE estimator 
    subcarrier_spacing = 50000; % (50 kHz)
    tau_rms = 0.7e-6; % Corresponds to the TU channel

    
    %...
    %...
    %channel_estimate = %...
  otherwise
    error('chest:noAlg', 'Specified algorithm does not exist.')
end
