function symbols = ofdm_demodulator(signal, num_subcarriers, guard_interval, channel_estimate_fd)
% function has tree tasks:
%   - remove CP
%   - transform to frequency domain
%   - channel equalization

% remove CP
signal = %....

% Transform the time-domain samples into frequency domain and normalize
symbols = %...

% If an estimate of the channel is passed to this function, perform frequency-domain equalization.
if nargin == 4,
	symbols = %...
end

% reshape symbols
symbols = symbols(:);