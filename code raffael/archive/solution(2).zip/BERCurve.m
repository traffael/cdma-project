% create BER plot

SNR  = [0:5:40];
nRep = 100;
alg = {'LS','MST','MMSE'};
nGuard=16;
nTones=128;
nSym=10;
numBits = nSym*nTones*2;

%load pn_sequence
%load ber_pn_seq
load channel_estimation_sequence

dataBits   = randi([0 1], 1, numBits);
txSym      = sqrt(2)*((dataBits(1:2:end) + 1j*dataBits(2:2:end)) - 0.5*(1+1j));
txSymChEst = [channel_estimation_sequence.' txSym];
txSymRe    = reshape(txSymChEst,nTones,[]);
txSymTim   = ifft(txSymRe)*sqrt(nTones);
txSymTotRe = [txSymTim(nTones-nGuard+1:nTones,:); txSymTim];


BER    = zeros(numel(alg),length(SNR),nRep);
BEROut = zeros(numel(alg),length(SNR));
figure(1)
clf(1)
figMar = {'r+-','go-.','k*--'};


for kt = 1:numel(alg)
  for kk = 1:numel(SNR)
    for km = 1:nRep
      b = zeros(1,128);
      nhighIdx = 1+round(15/2*rand);
      b(1:16) = 1/sqrt(2)*(randn(1,16) + 1j*randn(1,16))./(1:0.5:8.5);
      c = ifft(b)*sqrt(128);
      c = c/(max(abs(c)));
      plot(lin2dB(abs(c)))
      c = [c(128-16+1:128) c].';
      H = repmat(c,1,size(txSymTotRe,2));
      txSymTimesH = txSymTotRe .* H;
      txSymTot   = txSymTimesH(:);
      BER(kt,kk,km) = task1BER(SNR(kk), 1,0,alg{kt},km,txSymTot,dataBits.');
    end
  end
  localBER = zeros(length(SNR),nRep);
  localBER(:,:) = BER(kt,:,:);
  semilogy(SNR,mean(localBER,2)',figMar{kt})
  BEROut(kt,:) = mean(localBER,2)';
  hold on;
end
legend(alg)
hold off
BEROut
