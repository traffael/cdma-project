function symbols = ofdm_demodulator(signal, num_subcarriers, guard_interval, channel_estimate_fd)

signal = reshape(signal, num_subcarriers + guard_interval, length(signal) / (num_subcarriers + guard_interval));
signal(1:guard_interval, :) = [];  % Remove the guard interval
symbols = fft(signal) / sqrt(num_subcarriers);  % Transform the time-domain samples into frequency domain

% If an estimate of the channel is passed to this function, perform frequency-domain equalization.
if nargin == 4,
	symbols = symbols ./ repmat(channel_estimate_fd, 1, size(symbols, 2));
end

symbols = symbols(:);