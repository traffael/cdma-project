function image_decoder(b, image_size)
% Convert the bit stream "b" into an image and display it.
% The vector "image_size" of length 2 contains the dimensions (in pixels) of the image (height x width)

if length(b) ~= 8 * prod(image_size), error('Input vector has wrong size.'), end

b1 = reshape(b, 8, length(b)/8).';
image = bi2de(b1);
image = reshape(image, image_size(2), image_size(1)).';
imageview(image);
end