function BER = task1(SNR, mode, doPlot, algorithm, rndState, signal, ber_pn_seq)
% Mode = 0: Image
% Mode = 1: PN-Sequence for BER calculation

% random generator initialization
if nargin < 5
  rndState = 1;
end
rng(rndState);

% main system parameters
os_factor = 1;
num_subcarriers = 128;
guard_interval = 16;

% data input selection
if (mode == 0)
	load image
	data_length = prod(image_size) * 8 / 2; % Number of QPSK data symbols
else
  if nargin < 7
    load pn_sequence
    load ber_pn_seq
  end
	data_length = length(ber_pn_seq) / 2; % Number of QPSK data symbols
end

% number of ofdm symbols
num_ofdm_symbols = ceil(data_length / num_subcarriers);

% adding noise
rx_signal = awgn(signal, SNR); clear signal;

% frame start detection
beginning_of_data = frame_sync(rx_signal, os_factor); % Index of the first data symbol

% first OFDM symbol for channel estimation 
ch_est_seq_rx = rx_signal(beginning_of_data : beginning_of_data + (num_subcarriers + guard_interval) - 1);

% reference tx channel estimation sequence (loads a variable "channel_estimation_sequence")
load channel_estimation_sequence;

% channel estimation
CTF_est_ls    = ofdm_channel_estimator(ch_est_seq_rx, channel_estimation_sequence, num_subcarriers, guard_interval, SNR, 'LS');
CTF_est_mmse  = ofdm_channel_estimator(ch_est_seq_rx, channel_estimation_sequence, num_subcarriers, guard_interval, SNR, 'MMSE');
CTF_est_mst   = ofdm_channel_estimator(ch_est_seq_rx, channel_estimation_sequence, num_subcarriers, guard_interval, SNR, 'MST');

% ploting estimated channels
if doPlot
  figure(1)
  plot(20*log10(abs(CTF_est_ls))); hold on
  plot(20*log10(abs(CTF_est_mmse)), 'r');
  plot(20*log10(abs(CTF_est_mst)), 'g');
  hold off
  legend('LS', 'MMSE', 'MST');
  xlabel('Subcarrier'); ylabel('Gain (dB)')
end

% data OFDM symbol extraction
beginning_of_data = beginning_of_data + num_subcarriers + guard_interval; % The "real" data starts after the channel estimation sequence.
payload_data = rx_signal(beginning_of_data : beginning_of_data + num_ofdm_symbols * (num_subcarriers + guard_interval) - 1);

% demodulate rx symbols
switch algorithm
  case 'LS'
    payload_data = ofdm_demodulator(payload_data, num_subcarriers, guard_interval, CTF_est_ls);
  case 'MST'
    payload_data = ofdm_demodulator(payload_data, num_subcarriers, guard_interval, CTF_est_mst);
  case 'MMSE'
    payload_data = ofdm_demodulator(payload_data, num_subcarriers, guard_interval, CTF_est_mmse);
  otherwise
    error('task1:noAlg', 'Algorithm not found. Existing: LS, MST, MMSE')
end
% cut out data only (last ofdm symbol may not fully used)
payload_data = payload_data(1 : data_length);

% demap payload data
rxBits = demapper(payload_data);

% do something with the received data
if (mode == 0)
	image_decoder(rxBits, image_size);
  BER = [];
else
	BER = sum(ber_pn_seq ~= rxBits) / length(ber_pn_seq);
end
